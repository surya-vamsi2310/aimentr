import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-courses',
  templateUrl: './dashboard-courses.component.html',
  styleUrls: ['./dashboard-courses.component.scss']
})
export class DashboardCoursesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
